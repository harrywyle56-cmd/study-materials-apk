# Source and build audit (2026-11-12)

## Scope and limits

Reviewed the supplied source archive (171 ZIP entries), Tauri configuration/capabilities, frontend and Rust source, package manifests/lockfiles, and GitHub Actions workflows. This is a static review, not a guarantee that every runtime behavior or every upstream dependency is safe. No APK was produced during this review.

## Findings

- No clear backdoor or malware behavior was identified in the reviewed first-party source: no hidden shell execution, credential exfiltration endpoint, obfuscated payload loader, or unexplained persistence mechanism was found.
- Authentication credentials are sent to the configured service API and session tokens are persisted in the app data directory. This is expected app behavior, but users should only sign in if they trust the service and its operators.
- The app fetches mirror hostnames from `https://huangguoai.pages.dev/` and then communicates with those HTTPS hosts. This is a supply-chain/trust boundary: a compromised mirror list or service can influence where app data/media requests go. The code contains URL/IP restrictions and HTTPS downgrade checks, but static review cannot establish the safety of the remote service.
- Media proxying, image decryption, and dynamic mirror discovery appear to support the app's stated playback functionality; they are not, by themselves, evidence of malware.
- GitHub Actions previously failed the Android job whenever the four Android signing secrets were absent. The workflow now produces clearly named unsigned APK artifacts when no keystore is configured, and signs APKs when all required secrets are present. A partially configured keystore now fails explicitly.
- `pnpm install --frozen-lockfile` could not be run in this environment because the package registry was unreachable (`EAI_AGAIN registry.npmjs.org`). Therefore TypeScript, Rust, and Android compilation remain unverified here.

## Build from GitHub Actions

1. Push this project to a GitHub repository.
2. Open **Actions → Release → Run workflow** (or push a `v*` tag to trigger a release build).
3. Open the completed run and download the `android` artifact.
4. Without signing secrets, files are named `HGhub_<version>_<abi>-unsigned.apk`; they are not install-ready until signed. To have CI sign them, configure repository Actions secrets: `ANDROID_KEY_BASE64`, `ANDROID_KEY_ALIAS`, `ANDROID_KEYSTORE_PASSWORD`, and `ANDROID_KEY_PASSWORD`.

The workflow builds APKs for `aarch64`, `armv7`, and `x86_64` Android targets. The exact artifact filenames/ABI directory naming are determined by the Tauri/Gradle build output and the workflow collection step.
